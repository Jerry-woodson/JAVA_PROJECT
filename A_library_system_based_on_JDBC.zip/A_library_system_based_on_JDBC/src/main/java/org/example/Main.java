package org.example;
import java.util.Scanner;
import java.sql.*;

public class Main {
    private static final String DB_URL = "jdbc:derby://localhost:1527/library";
    private static final String DB_USER = "lijiarui";
    private static final String DB_PAS = "lijiarui";
    public static void main(String []args) {
        //进行输入 try-catch检查
        try {
            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PAS);
            Scanner scanner = new Scanner(System.in);
            boolean isReady = true;
            while(isReady) {
                System.out.println("欢迎来到图书管理系统");
                System.out.println("1.图书的录入");
                System.out.println("2.列表查看图书信息");
                System.out.println("3.修改图书信息");
                System.out.println("4.删除图书信息");
                System.out.println("5.退出");
                System.out.print("请选择:");
                int result = scanner.nextInt();
                // 消耗换行符
                scanner.nextLine();
                switch(result) {
                    case 1:
                        System.out.println("图书的录入");
                        String bookName = scanner.nextLine();
                        InsertBook(connection, bookName);
                        break;
                    case 2:
                        System.out.println("列表查看图书信息");
                        ListBook(connection);
                        break;
                    case 3:
                        System.out.println("修改图书信息");
                        System.out.print("请输入原来图书的id:");
                        int bookID = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("请输入新的图书的名称:");
                        String bookName_new = scanner.nextLine();
                        AdjustBook(connection, bookID, bookName_new);
                        break;
                    case 4:
                        System.out.println("删除图书信息");
                        int res = scanner.nextInt();
                        scanner.nextLine();
                        DeleteBook(connection, res);
                        break;
                    default:
                        System.out.println("正在退出系统");
                        isReady = false;
                        break;
                }
            }
            connection.close();
        }
        catch(SQLException e) {
            e.printStackTrace();
        }
    }
    // 进行图书的录入
    private static void InsertBook(Connection connection, String bookName) throws SQLException {
        String sql = "INSERT INTO books (name) VALUES (?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, bookName);
        preparedStatement.executeUpdate();

    }
    // 列表查看图书信息
    private static void ListBook(Connection connection) throws SQLException {
        String sql = "SELECT * FROM books";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        while(resultSet.next()) {
            int id = resultSet.getInt("id");
            String name = resultSet.getString("name");
            System.out.println("图书ID" + id + "图书名称" + name);
        }
    }
    //修改图书信息
    private static void AdjustBook(Connection connection, int bookID, String bookName_new) throws SQLException {
        String sql = "UPDATE books SET name = ? WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(2, bookID);
        preparedStatement.setString(1, bookName_new);
        int AdjustRows = preparedStatement.executeUpdate();
        if(AdjustRows > 0) {
            System.out.println("修改图书信息成功");
        }
        else {
            System.out.println("未能正确修改图书信息");
        }
    }
    //删除图书信息
    private static void DeleteBook(Connection connection, int res) throws SQLException {
        String sql = "DELETE FROM books WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, res);
        int DeleteRows = preparedStatement.executeUpdate();;
        if(DeleteRows > 0) {
            System.out.println("删除图书信息成功");
        }
        else {
            System.out.println("未能正确删除图书信息");
        }
    }
}
